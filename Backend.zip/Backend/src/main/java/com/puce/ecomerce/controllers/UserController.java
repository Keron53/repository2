package com.puce.ecomerce.controllers;

import java.util.LinkedHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.puce.ecomerce.models.User;
import com.puce.ecomerce.services.UserService;

@RestController
@RequestMapping("users")
@CrossOrigin("*")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@PostMapping("/register")
	public User register(@RequestBody LinkedHashMap<String,String> body) {
		String firstName= body.get("firstName");
		String lastName= body.get("lastName");
		String email= body.get("email");
		String password= body.get("password");
		String address= body.get("address");
		String phoneNumber= body.get("phoneNumber");
		
		return userService.registerUser(firstName, lastName, email, password, address, phoneNumber);
	}

}
